import 'package:flutter/material.dart';

class EnglishCourseScreen extends StatefulWidget {
  const EnglishCourseScreen({Key? key}) : super(key: key);

  @override
  _EnglishCourseScreenState createState() => _EnglishCourseScreenState();
}

class _EnglishCourseScreenState extends State<EnglishCourseScreen> {
  final List<Map<String, dynamic>> _units = [
    {
      'title': 'الوحدة الأولى: الحروف والأصوات',
      'description': 'تعلم الحروف الإنجليزية ونطقها الصحيح',
      'progress': 0.8,
      'lessons': [
        {
          'title': 'الدرس الأول: الحروف الكبيرة',
          'description': 'تعلم الحروف الإنجليزية الكبيرة (A-Z)',
          'duration': '20 دقيقة',
          'completed': true,
        },
        {
          'title': 'الدرس الثاني: الحروف الصغيرة',
          'description': 'تعلم الحروف الإنجليزية الصغيرة (a-z)',
          'duration': '20 دقيقة',
          'completed': true,
        },
      ],
    },
    {
      'title': 'الوحدة الثانية: الكلمات والجمل البسيطة',
      'description': 'تعلم التحية والتعارف والألوان والأرقام',
      'progress': 0.5,
      'lessons': [
        {
          'title': 'الدرس الأول: التحية والتعارف',
          'description': 'تعلم كيفية التحية والتعارف باللغة الإنجليزية',
          'duration': '25 دقيقة',
          'completed': true,
        },
        {
          'title': 'الدرس الثاني: الألوان والأرقام',
          'description': 'تعلم أسماء الألوان والأرقام باللغة الإنجليزية',
          'duration': '25 دقيقة',
          'completed': false,
        },
      ],
    },
  ];

  int _selectedUnitIndex = 0;
  int _selectedLessonIndex = 0;
  bool _isLessonView = false;
  
  // متغيرات للتمارين التفاعلية
  List<String> _selectedLetters = [];
  Map<String, String> _matchedPairs = {};
  String? _selectedTranslation;
  Color? _selectedColor;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isLessonView
            ? _units[_selectedUnitIndex]['lessons'][_selectedLessonIndex]['title']
            : 'كورس تأسيس اللغة الإنجليزية'),
        leading: _isLessonView
            ? IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () {
                  setState(() {
                    _isLessonView = false;
                  });
                },
              )
            : null,
      ),
      body: _isLessonView
          ? _buildLessonContent()
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCourseHeader(),
                  const SizedBox(height: 24),
                  ...List.generate(
                    _units.length,
                    (index) => _buildUnitCard(index),
                  ),
                  const SizedBox(height: 24),
                  _buildCourseStats(),
                ],
              ),
            ),
    );
  }

  Widget _buildCourseHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              'https://cdn-icons-png.flaticon.com/512/1791/1791336.png',
              width: 80,
              height: 80,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'كورس تأسيس اللغة الإنجليزية',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'تعلم أساسيات اللغة الإنجليزية من الصفر',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildInfoChip('${_getTotalUnits()} وحدات'),
                    const SizedBox(width: 8),
                    _buildInfoChip('${_getTotalLessons()} درس'),
                    const SizedBox(width: 8),
                    _buildInfoChip('${_getTotalDuration()} دقيقة'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.shade100),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          color: Colors.green.shade700,
        ),
      ),
    );
  }

  Widget _buildUnitCard(int unitIndex) {
    final unit = _units[unitIndex];
    final progress = unit['progress'] as double;
    final lessons = unit['lessons'] as List<Map<String, dynamic>>;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        unit['title'],
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${lessons.length} دروس',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.green.shade700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  unit['description'],
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: progress,
                          backgroundColor: Colors.grey.shade200,
                          color: progress > 0 ? Colors.green : Colors.grey,
                          minHeight: 8,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${(progress * 100).toInt()}%',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: progress > 0 ? Colors.green : Colors.grey,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: lessons.length,
            separatorBuilder: (context, index) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final lesson = lessons[index];
              return ListTile(
                title: Text(
                  lesson['title'],
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: lesson['completed'] ? Colors.black : Colors.black54,
                  ),
                ),
                subtitle: Text(
                  lesson['description'],
                  style: TextStyle(
                    fontSize: 12,
                    color: lesson['completed'] ? Colors.black54 : Colors.black38,
                  ),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      lesson['duration'],
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (lesson['completed'])
                      const Icon(
                        Icons.check_circle,
                        color: Colors.green,
                        size: 20,
                      )
                    else
                      Icon(
                        Icons.play_circle_fill,
                        color: Colors.blue.shade300,
                        size: 20,
                      ),
                  ],
                ),
                onTap: () {
                  setState(() {
                    _selectedUnitIndex = unitIndex;
                    _selectedLessonIndex = index;
                    _isLessonView = true;
                    
                    // إعادة تعيين متغيرات التمارين عند فتح درس جديد
                    _selectedLetters = [];
                    _matchedPairs = {};
                    _selectedTranslation = null;
                    _selectedColor = null;
                  });
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildLessonContent() {
    final lesson = _units[_selectedUnitIndex]['lessons'][_selectedLessonIndex];
    final isFirstLesson = _selectedUnitIndex == 0 && _selectedLessonIndex == 0;
    final isSecondLesson = _selectedUnitIndex == 0 && _selectedLessonIndex == 1;
    final isThirdLesson = _selectedUnitIndex == 1 && _selectedLessonIndex == 0;
    final isFourthLesson = _selectedUnitIndex == 1 && _selectedLessonIndex == 1;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.green.shade200),
                  ),
                  child: Text(
                    '${_selectedLessonIndex + 1}',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade700,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        lesson['title'],
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        lesson['description'],
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          if (isFirstLesson) _buildFirstLessonContent(),
          if (isSecondLesson) _buildSecondLessonContent(),
          if (isThirdLesson) _buildThirdLessonContent(),
          if (isFourthLesson) _buildFourthLessonContent(),
          const SizedBox(height: 24),
          _buildLessonNavigation(),
        ],
      ),
    );
  }

  Widget _buildFirstLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'الحروف الإنجليزية الكبيرة (A-Z)',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'تتكون اللغة الإنجليزية من 26 حرفاً، وهي تنقسم إلى حروف كبيرة (Capital Letters) وحروف صغيرة (Small Letters). في هذا الدرس سنتعلم الحروف الكبيرة.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            childAspectRatio: 1,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: 26,
          itemBuilder: (context, index) {
            final letter = String.fromCharCode(65 + index);
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      letter,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.green.shade700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _getLetterExample(letter),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: اضغط على الحروف بالترتيب الصحيح',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.green.shade200),
          ),
          child: Column(
            children: [
              const Text(
                'اضغط على الحروف بالترتيب الصحيح من A إلى Z',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 16),
              // عرض الحروف المختارة
              if (_selectedLetters.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _selectedLetters.join(' - '),
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade700,
                    ),
                  ),
                ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: List.generate(
                  26,
                  (index) {
                    final randomIndex = (index * 7) % 26;
                    final letter = String.fromCharCode(65 + randomIndex);
                    final isSelected = _selectedLetters.contains(letter);
                    final isCorrect = _selectedLetters.isNotEmpty && 
                                     _selectedLetters.last == letter && 
                                     _selectedLetters.length == (randomIndex + 1);
                    
                    return ElevatedButton(
                      onPressed: isSelected ? null : () {
                        setState(() {
                          final expectedLetter = String.fromCharCode(65 + _selectedLetters.length);
                          
                          if (letter == expectedLetter) {
                            // إجابة صحيحة
                            _selectedLetters.add(letter);
                            _showFeedback(context, true, 'إجابة صحيحة! 👍');
                            
                            // إذا أكمل الطالب جميع الحروف
                            if (_selectedLetters.length == 26) {
                              _showCompletionDialog(context, 'أحسنت! لقد أكملت ترتيب الحروف الإنجليزية بنجاح.');
                            }
                          } else {
                            // إجابة خاطئة
                            _showFeedback(context, false, 'إجابة خاطئة. الحرف التالي هو $expectedLetter');
                          }
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isSelected 
                            ? Colors.grey.shade300 
                            : isCorrect 
                                ? Colors.green.shade100 
                                : Colors.white,
                        foregroundColor: isSelected 
                            ? Colors.grey.shade700 
                            : Colors.green.shade700,
                        padding: const EdgeInsets.all(12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        letter,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              // زر إعادة المحاولة
              if (_selectedLetters.isNotEmpty)
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _selectedLetters = [];
                    });
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('إعادة المحاولة'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade50,
                    foregroundColor: Colors.blue.shade700,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSecondLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'الحروف الإنجليزية الصغيرة (a-z)',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'بعد أن تعلمنا الحروف الكبيرة، سنتعلم الآن الحروف الصغيرة (Small Letters). لكل حرف كبير يوجد حرف صغير مقابل له.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            childAspectRatio: 1,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: 26,
          itemBuilder: (context, index) {
            final letter = String.fromCharCode(97 + index);
            final capitalLetter = String.fromCharCode(65 + index);
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          capitalLetter,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey.shade400,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          letter,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.green.shade700,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _getLetterExample(letter),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: اربط بين الحرف الكبير والحرف الصغير',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.green.shade200),
          ),
          child: Column(
            children: [
              const Text(
                'اضغط على الحرف الكبير ثم الحرف الصغير المقابل له',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 16),
              // عرض الأزواج المطابقة
              if (_matchedPairs.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _matchedPairs.entries.map((entry) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.green.shade200),
                        ),
                        child: Text(
                          '${entry.key} - ${entry.value}',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.green.shade700,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      alignment: WrapAlignment.center,
                      children: List.generate(
                        10,
                        (index) {
                          final randomIndex = (index * 3) % 26;
                          final letter = String.fromCharCode(65 + randomIndex);
                          final isMatched = _matchedPairs.containsKey(letter);
                          
                          return ElevatedButton(
                            onPressed: isMatched ? null : () {
                              setState(() {
                                // إذا لم يكن هناك حرف كبير مختار بعد
                                if (_selectedLetters.isEmpty) {
                                  _selectedLetters.add(letter);
                                }
                                // إذا كان هناك حرف كبير مختار بالفعل، نتجاهل الضغط على حرف كبير آخر
                              });
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isMatched 
                                  ? Colors.grey.shade300 
                                  : _selectedLetters.isNotEmpty && _selectedLetters[0] == letter
                                      ? Colors.blue.shade100
                                      : Colors.white,
                              foregroundColor: isMatched 
                                  ? Colors.grey.shade700 
                                  : Colors.blue.shade700,
                              padding: const EdgeInsets.all(12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              letter,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      alignment: WrapAlignment.center,
                      children: List.generate(
                        10,
                        (index) {
                          final randomIndex = (index * 7) % 26;
                          final letter = String.fromCharCode(97 + randomIndex);
                          final capitalLetter = String.fromCharCode(65 + randomIndex);
                          final isMatched = _matchedPairs.containsValue(letter);
                          
                          return ElevatedButton(
                            onPressed: isMatched || _selectedLetters.isEmpty ? null : () {
                              setState(() {
                                final selectedCapital = _selectedLetters[0];
                                final expectedSmall = String.fromCharCode(selectedCapital.codeUnitAt(0) + 32);
                                
                                if (letter == expectedSmall) {
                                  // إجابة صحيحة
                                  _matchedPairs[selectedCapital] = letter;
                                  _selectedLetters = [];
                                  _showFeedback(context, true, 'إجابة صحيحة! 👍');
                                  
                                  // إذا أكمل الطالب جميع الأزواج
                                  if (_matchedPairs.length == 10) {
                                    _showCompletionDialog(context, 'أحسنت! لقد أكملت مطابقة الحروف الكبيرة والصغيرة بنجاح.');
                                  }
                                } else {
                                  // إجابة خاطئة
                                  _selectedLetters = [];
                                  _showFeedback(context, false, 'إجابة خاطئة. حاول مرة أخرى.');
                                }
                              });
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isMatched 
                                  ? Colors.grey.shade300 
                                  : Colors.white,
                              foregroundColor: isMatched 
                                  ? Colors.grey.shade700 
                                  : Colors.green.shade700,
                              padding: const EdgeInsets.all(12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              letter,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // زر إعادة المحاولة
              if (_matchedPairs.isNotEmpty || _selectedLetters.isNotEmpty)
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _matchedPairs = {};
                      _selectedLetters = [];
                    });
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('إعادة المحاولة'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade50,
                    foregroundColor: Colors.blue.shade700,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildThirdLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'التحية والتعارف',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'في هذا الدرس سنتعلم كيفية التحية والتعارف باللغة الإنجليزية. هذه العبارات مهمة جداً في المحادثات اليومية.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _greetings.length,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final greeting = _greetings[index];
            return Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      greeting['icon'] as IconData,
                      color: Colors.green.shade700,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          greeting['english'],
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          greeting['arabic'],
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.volume_up),
                    color: Colors.blue.shade700,
                    onPressed: () {
                      // Play audio
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('جاري تشغيل: ${greeting['english']}'),
                          duration: const Duration(seconds: 1),
                        ),
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: اختر الترجمة الصحيحة',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.green.shade200),
          ),
          child: Column(
            children: [
              const Text(
                'اختر الترجمة العربية الصحيحة للعبارة الإنجليزية',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Text(
                    'Nice to meet you',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _buildTranslationOption('صباح الخير', false),
                  _buildTranslationOption('مساء الخير', false),
                  _buildTranslationOption('تشرفت بمقابلتك', true),
                  _buildTranslationOption('كيف حالك؟', false),
                ],
              ),
              const SizedBox(height: 16),
              // زر إعادة المحاولة
              if (_selectedTranslation != null)
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _selectedTranslation = null;
                    });
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('سؤال آخر'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade50,
                    foregroundColor: Colors.blue.shade700,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTranslationOption(String text, bool isCorrect) {
    final isSelected = _selectedTranslation == text;
    
    return ElevatedButton(
      onPressed: _selectedTranslation != null ? null : () {
        setState(() {
          _selectedTranslation = text;
          
          if (isCorrect) {
            // إجابة صحيحة
            _showFeedback(context, true, 'إجابة صحيحة! 👍');
          } else {
            // إجابة خاطئة
            _showFeedback(context, false, 'إجابة خاطئة. الإجابة الصحيحة هي: تشرفت بمقابلتك');
          }
        });
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: _selectedTranslation == null 
            ? Colors.white 
            : isSelected 
                ? isCorrect 
                    ? Colors.green.shade100 
                    : Colors.red.shade100
                : isCorrect && _selectedTranslation != null
                    ? Colors.green.shade100
                    : Colors.white,
        foregroundColor: _selectedTranslation == null 
            ? Colors.black 
            : isSelected 
                ? isCorrect 
                    ? Colors.green.shade700 
                    : Colors.red.shade700
                : Colors.black,
        padding: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      child: Text(text),
    );
  }

  Widget _buildFourthLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'الألوان والأرقام',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'في هذا الدرس سنتعلم أسماء الألوان والأرقام باللغة الإنجليزية. هذه المفردات أساسية ومهمة في اللغة الإنجليزية.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        const Text(
          'الألوان',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            childAspectRatio: 1,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: _colors.length,
          itemBuilder: (context, index) {
            final colorItem = _colors[index];
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: colorItem['color'] as Color,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    colorItem['english'],
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    colorItem['arabic'],
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 24),
        const Text(
          'الأرقام',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 5,
            childAspectRatio: 1,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: 10,
          itemBuilder: (context, index) {
            final number = index + 1;
            final numberWord = _getNumberWord(number);
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    number.toString(),
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    numberWord,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: اختر اللون الصحيح',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.green.shade200),
          ),
          child: Column(
            children: [
              const Text(
                'اختر اللون المناسب للكلمة الإنجليزية',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Text(
                    'Red',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildColorOption(Colors.blue, false),
                  _buildColorOption(Colors.red, true),
                  _buildColorOption(Colors.green, false),
                  _buildColorOption(Colors.yellow, false),
                ],
              ),
              const SizedBox(height: 16),
              // زر إعادة المحاولة
              if (_selectedColor != null)
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _selectedColor = null;
                    });
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('سؤال آخر'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade50,
                    foregroundColor: Colors.blue.shade700,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildColorOption(Color color, bool isCorrect) {
    final isSelected = _selectedColor == color;
    final borderColor = _selectedColor == null 
        ? Colors.grey.shade300 
        : isSelected 
            ? isCorrect 
                ? Colors.green 
                : Colors.red
            : isCorrect && _selectedColor != null
                ? Colors.green
                : Colors.grey.shade300;
    
    return InkWell(
      onTap: _selectedColor != null ? null : () {
        setState(() {
          _selectedColor = color;
          
          if (isCorrect) {
            // إجابة صحيحة
            _showFeedback(context, true, 'إجابة صحيحة! 👍');
          } else {
            // إجابة خاطئة
            _showFeedback(context, false, 'إجابة خاطئة. اللون الصحيح هو الأحمر.');
          }
        });
      },
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: borderColor,
            width: _selectedColor != null ? 3 : 1,
          ),
        ),
      ),
    );
  }

  Widget _buildLessonNavigation() {
    final hasNextLesson = _selectedLessonIndex < _units[_selectedUnitIndex]['lessons'].length - 1;
    final hasNextUnit = _selectedUnitIndex < _units.length - 1;
    final hasPreviousLesson = _selectedLessonIndex > 0;
    final hasPreviousUnit = _selectedUnitIndex > 0;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        if (hasPreviousLesson || hasPreviousUnit)
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                if (hasPreviousLesson) {
                  _selectedLessonIndex--;
                } else if (hasPreviousUnit) {
                  _selectedUnitIndex--;
                  _selectedLessonIndex = _units[_selectedUnitIndex]['lessons'].length - 1;
                }
                
                // إعادة تعيين متغيرات التمارين عند تغيير الدرس
                _selectedLetters = [];
                _matchedPairs = {};
                _selectedTranslation = null;
                _selectedColor = null;
              });
            },
            icon: const Icon(Icons.arrow_back),
            label: const Text('الدرس السابق'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.grey.shade200,
              foregroundColor: Colors.black,
            ),
          )
        else
          const SizedBox(),
        ElevatedButton(
          onPressed: () {
            setState(() {
              _isLessonView = false;
            });
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue.shade700,
            foregroundColor: Colors.white,
          ),
          child: const Text('إنهاء الدرس'),
        ),
        if (hasNextLesson || hasNextUnit)
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                if (hasNextLesson) {
                  _selectedLessonIndex++;
                } else if (hasNextUnit) {
                  _selectedUnitIndex++;
                  _selectedLessonIndex = 0;
                }
                
                // إعادة تعيين متغيرات التمارين عند تغيير الدرس
                _selectedLetters = [];
                _matchedPairs = {};
                _selectedTranslation = null;
                _selectedColor = null;
              });
            },
            icon: const Icon(Icons.arrow_forward),
            label: const Text('الدرس التالي'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green.shade700,
              foregroundColor: Colors.white,
            ),
          )
        else
          const SizedBox(),
      ],
    );
  }

  Widget _buildCourseStats() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'إحصائيات التقدم',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem('الدروس المكتملة', '${_getCompletedLessonsCount()}/${_getTotalLessons()}', Icons.check_circle, Colors.green),
              _buildStatItem('الوقت المستغرق', '45 دقيقة', Icons.access_time, Colors.orange),
              _buildStatItem('النقاط المكتسبة', '120', Icons.star, Colors.amber),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: color,
            size: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // دالة لعرض التغذية الراجعة للطالب
  void _showFeedback(BuildContext context, bool isCorrect, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isCorrect ? Icons.check_circle : Icons.error,
              color: Colors.white,
            ),
            const SizedBox(width: 8),
            Text(message),
          ],
        ),
        backgroundColor: isCorrect ? Colors.green : Colors.red,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // دالة لعرض نافذة إكمال التمرين
  void _showCompletionDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(
              Icons.emoji_events,
              color: Colors.amber,
              size: 30,
            ),
            const SizedBox(width: 8),
            const Text('أحسنت!'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(message),
            const SizedBox(height: 16),
            const Text(
              'لقد حصلت على 10 نقاط!',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('متابعة'),
          ),
        ],
      ),
    );
  }

  String _getLetterExample(String letter) {
    final examples = {
      'A': 'Apple',
      'B': 'Ball',
      'C': 'Cat',
      'D': 'Dog',
      'E': 'Egg',
      'F': 'Fish',
      'G': 'Girl',
      'H': 'Hat',
      'I': 'Ice',
      'J': 'Jam',
      'K': 'King',
      'L': 'Lion',
      'M': 'Moon',
      'N': 'Nest',
      'O': 'Orange',
      'P': 'Pen',
      'Q': 'Queen',
      'R': 'Rose',
      'S': 'Sun',
      'T': 'Tree',
      'U': 'Umbrella',
      'V': 'Van',
      'W': 'Water',
      'X': 'X-ray',
      'Y': 'Yacht',
      'Z': 'Zoo',
      'a': 'Apple',
      'b': 'Ball',
      'c': 'Cat',
      'd': 'Dog',
      'e': 'Egg',
      'f': 'Fish',
      'g': 'Girl',
      'h': 'Hat',
      'i': 'Ice',
      'j': 'Jam',
      'k': 'King',
      'l': 'Lion',
      'm': 'Moon',
      'n': 'Nest',
      'o': 'Orange',
      'p': 'Pen',
      'q': 'Queen',
      'r': 'Rose',
      's': 'Sun',
      't': 'Tree',
      'u': 'Umbrella',
      'v': 'Van',
      'w': 'Water',
      'x': 'X-ray',
      'y': 'Yacht',
      'z': 'Zoo',
    };
    return examples[letter] ?? '';
  }

  String _getNumberWord(int number) {
    final words = [
      'One',
      'Two',
      'Three',
      'Four',
      'Five',
      'Six',
      'Seven',
      'Eight',
      'Nine',
      'Ten',
    ];
    return words[number - 1];
  }

  int _getTotalUnits() {
    return _units.length;
  }

  int _getTotalLessons() {
    int count = 0;
    for (final unit in _units) {
      final lessons = unit['lessons'] as List<Map<String, dynamic>>;
      count += lessons.length;
    }
    return count;
  }

  int _getCompletedLessonsCount() {
    int count = 0;
    for (int i = 0; i < _units.length; i++) {
      final lessons = _units[i]['lessons'] as List<Map<String, dynamic>>;
      for (int j = 0; j < lessons.length; j++) {
        if (lessons[j]['completed'] == true) {
          count++;
        }
      }
    }
    return count;
  }

  int _getTotalDuration() {
    int minutes = 0;
    for (final unit in _units) {
      final lessons = unit['lessons'] as List<Map<String, dynamic>>;
      for (final lesson in lessons) {
        final duration = lesson['duration'] as String;
        final durationMinutes = int.parse(duration.split(' ')[0]);
        minutes += durationMinutes;
      }
    }
    return minutes;
  }

  final List<Map<String, dynamic>> _greetings = [
    {
      'english': 'Hello',
      'arabic': 'مرحباً',
      'icon': Icons.waving_hand,
    },
    {
      'english': 'Good morning',
      'arabic': 'صباح الخير',
      'icon': Icons.wb_sunny,
    },
    {
      'english': 'Good afternoon',
      'arabic': 'مساء الخير',
      'icon': Icons.wb_twilight,
    },
    {
      'english': 'Good evening',
      'arabic': 'مساء الخير',
      'icon': Icons.nightlight_round,
    },
    {
      'english': 'How are you?',
      'arabic': 'كيف حالك؟',
      'icon': Icons.sentiment_satisfied_alt,
    },
    {
      'english': 'I\'m fine, thank you',
      'arabic': 'أنا بخير، شكراً لك',
      'icon': Icons.thumb_up,
    },
    {
      'english': 'Nice to meet you',
      'arabic': 'تشرفت بمقابلتك',
      'icon': Icons.handshake,
    },
    {
      'english': 'My name is...',
      'arabic': 'اسمي...',
      'icon': Icons.person,
    },
    {
      'english': 'Goodbye',
      'arabic': 'وداعاً',
      'icon': Icons.waving_hand,
    },
  ];

  final List<Map<String, dynamic>> _colors = [
    {
      'english': 'Red',
      'arabic': 'أحمر',
      'color': Colors.red,
    },
    {
      'english': 'Blue',
      'arabic': 'أزرق',
      'color': Colors.blue,
    },
    {
      'english': 'Green',
      'arabic': 'أخضر',
      'color': Colors.green,
    },
    {
      'english': 'Yellow',
      'arabic': 'أصفر',
      'color': Colors.yellow,
    },
    {
      'english': 'Black',
      'arabic': 'أسود',
      'color': Colors.black,
    },
    {
      'english': 'White',
      'arabic': 'أبيض',
      'color': Colors.white,
    },
    {
      'english': 'Orange',
      'arabic': 'برتقالي',
      'color': Colors.orange,
    },
    {
      'english': 'Purple',
      'arabic': 'بنفسجي',
      'color': Colors.purple,
    },
    {
      'english': 'Pink',
      'arabic': 'وردي',
      'color': Colors.pink,
    },
  ];
}
