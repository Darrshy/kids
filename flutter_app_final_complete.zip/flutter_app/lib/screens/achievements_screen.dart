import 'package:flutter/material.dart';

class AchievementsScreen extends StatefulWidget {
  const AchievementsScreen({Key? key}) : super(key: key);

  @override
  _AchievementsScreenState createState() => _AchievementsScreenState();
}

class _AchievementsScreenState extends State<AchievementsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  final List<Map<String, dynamic>> _achievements = [
    {
      'title': 'بداية الرحلة',
      'description': 'أكمل أول درس في التطبيق',
      'icon': Icons.school,
      'color': Colors.blue,
      'completed': true,
      'date': '15 مايو 2025',
      'points': 10,
      'category': 'تعليمي',
    },
    {
      'title': 'المثابر',
      'description': 'استخدم التطبيق لمدة 7 أيام متتالية',
      'icon': Icons.calendar_today,
      'color': Colors.green,
      'completed': true,
      'date': '10 مايو 2025',
      'points': 50,
      'category': 'نشاط',
    },
    {
      'title': 'عبقري الحساب',
      'description': 'أكمل كورس الحساب الذهني بنجاح',
      'icon': Icons.calculate,
      'color': Colors.purple,
      'completed': false,
      'date': '',
      'points': 100,
      'category': 'تعليمي',
    },
    {
      'title': 'فنان صغير',
      'description': 'أكمل 10 رسومات في لعبة الرسم',
      'icon': Icons.brush,
      'color': Colors.orange,
      'completed': false,
      'date': '',
      'points': 50,
      'category': 'ألعاب',
    },
    {
      'title': 'متحدث اللغة',
      'description': 'أكمل كورس تأسيس اللغة الإنجليزية',
      'icon': Icons.language,
      'color': Colors.teal,
      'completed': false,
      'date': '',
      'points': 100,
      'category': 'تعليمي',
    },
    {
      'title': 'حلال الألغاز',
      'description': 'حل 20 لغزاً في لعبة الألغاز الحسابية',
      'icon': Icons.extension,
      'color': Colors.red,
      'completed': false,
      'date': '',
      'points': 75,
      'category': 'ألعاب',
    },
    {
      'title': 'المستكشف',
      'description': 'زر جميع أقسام التطبيق',
      'icon': Icons.explore,
      'color': Colors.amber,
      'completed': true,
      'date': '5 مايو 2025',
      'points': 25,
      'category': 'نشاط',
    },
    {
      'title': 'الصديق الاجتماعي',
      'description': 'أضف 5 أصدقاء إلى قائمة أصدقائك',
      'icon': Icons.people,
      'color': Colors.indigo,
      'completed': false,
      'date': '',
      'points': 50,
      'category': 'اجتماعي',
    },
    {
      'title': 'المتفوق',
      'description': 'احصل على علامة كاملة في اختبار',
      'icon': Icons.star,
      'color': Colors.amber,
      'completed': true,
      'date': '8 مايو 2025',
      'points': 75,
      'category': 'تعليمي',
    },
    {
      'title': 'المساعد',
      'description': 'ساعد صديقاً في حل مشكلة تعليمية',
      'icon': Icons.support,
      'color': Colors.cyan,
      'completed': false,
      'date': '',
      'points': 50,
      'category': 'اجتماعي',
    },
  ];
  
  int _totalPoints = 0;
  int _completedAchievements = 0;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    
    // حساب النقاط والإنجازات المكتملة
    for (var achievement in _achievements) {
      if (achievement['completed']) {
        _totalPoints += achievement['points'] as int;
        _completedAchievements++;
      }
    }
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإنجازات'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: const [
            Tab(text: 'الكل'),
            Tab(text: 'تعليمي'),
            Tab(text: 'ألعاب'),
            Tab(text: 'نشاط'),
            Tab(text: 'اجتماعي'),
          ],
        ),
      ),
      body: Column(
        children: [
          _buildAchievementsSummary(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildAchievementsList('الكل'),
                _buildAchievementsList('تعليمي'),
                _buildAchievementsList('ألعاب'),
                _buildAchievementsList('نشاط'),
                _buildAchievementsList('اجتماعي'),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildAchievementsSummary() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      color: Colors.blue.shade50,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            children: [
              const Text(
                'الإنجازات المكتملة',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '$_completedAchievements / ${_achievements.length}',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
            ],
          ),
          Column(
            children: [
              const Text(
                'مجموع النقاط',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '$_totalPoints',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          Column(
            children: [
              const Text(
                'المستوى',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${(_totalPoints / 100).floor() + 1}',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildAchievementsList(String category) {
    final filteredAchievements = category == 'الكل'
        ? _achievements
        : _achievements.where((a) => a['category'] == category).toList();
    
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: filteredAchievements.length,
      itemBuilder: (context, index) {
        final achievement = filteredAchievements[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16.0),
            leading: Container(
              padding: const EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                color: achievement['color'].withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(
                achievement['icon'],
                color: achievement['color'],
                size: 28,
              ),
            ),
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    achievement['title'],
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: achievement['completed'] ? Colors.black : Colors.grey,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: achievement['completed'] ? Colors.green : Colors.grey,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '+${achievement['points']}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                Text(
                  achievement['description'],
                  style: TextStyle(
                    fontSize: 14,
                    color: achievement['completed'] ? Colors.black87 : Colors.grey,
                  ),
                ),
                const SizedBox(height: 8),
                if (achievement['completed'])
                  Text(
                    'تم الإنجاز في: ${achievement['date']}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.green,
                    ),
                  )
                else
                  const Text(
                    'لم يتم الإنجاز بعد',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
              ],
            ),
            trailing: achievement['completed']
                ? const Icon(Icons.check_circle, color: Colors.green)
                : const Icon(Icons.lock, color: Colors.grey),
            onTap: () {
              _showAchievementDetails(achievement);
            },
          ),
        );
      },
    );
  }
  
  void _showAchievementDetails(Map<String, dynamic> achievement) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(achievement['title']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: achievement['color'].withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  achievement['icon'],
                  color: achievement['color'],
                  size: 48,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text('الوصف: ${achievement['description']}'),
            const SizedBox(height: 8),
            Text('الفئة: ${achievement['category']}'),
            const SizedBox(height: 8),
            Text('النقاط: ${achievement['points']}'),
            const SizedBox(height: 8),
            Text(
              achievement['completed']
                  ? 'الحالة: مكتمل (${achievement['date']})'
                  : 'الحالة: غير مكتمل',
              style: TextStyle(
                color: achievement['completed'] ? Colors.green : Colors.grey,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إغلاق'),
          ),
          if (!achievement['completed'])
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('استمر في التعلم لإكمال إنجاز "${achievement['title']}"'),
                  ),
                );
              },
              child: const Text('كيفية الإكمال'),
            ),
        ],
      ),
    );
  }
}
