import 'package:flutter/material.dart';
import 'dart:math' as math;

class PuzzleGameScreen extends StatefulWidget {
  const PuzzleGameScreen({Key? key}) : super(key: key);

  @override
  _PuzzleGameScreenState createState() => _PuzzleGameScreenState();
}

class _PuzzleGameScreenState extends State<PuzzleGameScreen> {
  final List<Map<String, dynamic>> _questions = [
    {
      'question': '5 + 3 = ?',
      'options': ['6', '7', '8', '9'],
      'correctIndex': 2,
    },
    {
      'question': '10 - 4 = ?',
      'options': ['4', '5', '6', '7'],
      'correctIndex': 2,
    },
    {
      'question': '3 × 3 = ?',
      'options': ['6', '9', '12', '15'],
      'correctIndex': 1,
    },
    {
      'question': '12 ÷ 4 = ?',
      'options': ['2', '3', '4', '5'],
      'correctIndex': 1,
    },
    {
      'question': '7 + 8 = ?',
      'options': ['13', '14', '15', '16'],
      'correctIndex': 2,
    },
  ];

  int _currentQuestionIndex = 0;
  int? _selectedOptionIndex;
  int _score = 0;
  bool _quizCompleted = false;
  bool _showingFeedback = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لعبة الألغاز الحسابية'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildGameHeader(),
            const SizedBox(height: 24),
            _quizCompleted ? _buildGameResults() : _buildQuestionCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildGameHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.purple.shade50,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.purple.withOpacity(0.2),
                  spreadRadius: 1,
                  blurRadius: 5,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Icon(
              Icons.extension,
              color: Colors.purple.shade700,
              size: 32,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'لعبة الألغاز الحسابية',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'اختبر مهاراتك في الحساب الذهني',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade700,
                  ),
                ),
                const SizedBox(height: 8),
                if (!_quizCompleted)
                  Row(
                    children: [
                      _buildInfoChip('السؤال ${_currentQuestionIndex + 1} من ${_questions.length}'),
                      const SizedBox(width: 8),
                      _buildInfoChip('النقاط: $_score'),
                    ],
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.purple.shade100),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          color: Colors.purple.shade700,
        ),
      ),
    );
  }

  Widget _buildQuestionCard() {
    final question = _questions[_currentQuestionIndex];
    final questionText = question['question'] as String;
    final options = question['options'] as List<String>;
    final correctIndex = question['correctIndex'] as int;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.purple.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                questionText,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.purple.shade800,
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemCount: options.length,
            itemBuilder: (context, index) {
              final option = options[index];
              final isSelected = _selectedOptionIndex == index;
              final isCorrect = index == correctIndex;
              
              return ElevatedButton(
                onPressed: _showingFeedback ? null : () {
                  setState(() {
                    _selectedOptionIndex = index;
                    _showingFeedback = true;
                    
                    if (isCorrect) {
                      // إجابة صحيحة
                      _score += 20;
                      _showFeedback(context, true, 'إجابة صحيحة! 👍');
                    } else {
                      // إجابة خاطئة
                      _showFeedback(context, false, 'إجابة خاطئة. الإجابة الصحيحة هي: ${options[correctIndex]}');
                    }
                    
                    // انتظر قليلاً قبل الانتقال للسؤال التالي
                    Future.delayed(const Duration(seconds: 2), () {
                      setState(() {
                        if (_currentQuestionIndex < _questions.length - 1) {
                          _currentQuestionIndex++;
                          _selectedOptionIndex = null;
                          _showingFeedback = false;
                        } else {
                          _quizCompleted = true;
                        }
                      });
                    });
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _selectedOptionIndex == null 
                      ? Colors.white 
                      : isSelected 
                          ? isCorrect 
                              ? Colors.green.shade100 
                              : Colors.red.shade100
                          : isCorrect && _selectedOptionIndex != null
                              ? Colors.green.shade100
                              : Colors.white,
                  foregroundColor: _selectedOptionIndex == null 
                      ? Colors.purple.shade700 
                      : isSelected 
                          ? isCorrect 
                              ? Colors.green.shade700 
                              : Colors.red.shade700
                          : Colors.purple.shade700,
                  padding: const EdgeInsets.all(16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: _selectedOptionIndex == null 
                          ? Colors.purple.shade200 
                          : isSelected 
                              ? isCorrect 
                                  ? Colors.green 
                                  : Colors.red
                              : isCorrect && _selectedOptionIndex != null
                                  ? Colors.green
                                  : Colors.purple.shade200,
                      width: 2,
                    ),
                  ),
                ),
                child: Text(
                  option,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          LinearProgressIndicator(
            value: (_currentQuestionIndex + 1) / _questions.length,
            backgroundColor: Colors.grey.shade200,
            color: Colors.purple,
            minHeight: 8,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
    );
  }

  Widget _buildGameResults() {
    final percentage = (_score / 100) * 100;
    
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            'نتيجة اللعبة',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: percentage >= 80 
                  ? Colors.green.shade50 
                  : percentage >= 60 
                      ? Colors.amber.shade50 
                      : Colors.red.shade50,
              shape: BoxShape.circle,
              border: Border.all(
                color: percentage >= 80 
                    ? Colors.green 
                    : percentage >= 60 
                        ? Colors.amber 
                        : Colors.red,
                width: 3,
              ),
            ),
            child: Column(
              children: [
                Text(
                  '$_score',
                  style: TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    color: percentage >= 80 
                        ? Colors.green.shade700 
                        : percentage >= 60 
                            ? Colors.amber.shade700 
                            : Colors.red.shade700,
                  ),
                ),
                Text(
                  'من 100',
                  style: TextStyle(
                    fontSize: 16,
                    color: percentage >= 80 
                        ? Colors.green.shade700 
                        : percentage >= 60 
                            ? Colors.amber.shade700 
                            : Colors.red.shade700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text(
            percentage >= 80 
                ? 'ممتاز! أحسنت العمل.' 
                : percentage >= 60 
                    ? 'جيد! استمر في التدريب.' 
                    : 'تحتاج إلى مزيد من التدريب.',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            percentage >= 80 
                ? 'لقد أظهرت مهارات ممتازة في الحساب الذهني!' 
                : percentage >= 60 
                    ? 'أنت على الطريق الصحيح. واصل التدريب لتحسين مهاراتك.' 
                    : 'لا تقلق، مع المزيد من الممارسة ستتحسن مهاراتك.',
            style: const TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _currentQuestionIndex = 0;
                    _selectedOptionIndex = null;
                    _score = 0;
                    _quizCompleted = false;
                    _showingFeedback = false;
                  });
                },
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة اللعب'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple.shade100,
                  foregroundColor: Colors.purple.shade700,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                icon: const Icon(Icons.home),
                label: const Text('العودة للرئيسية'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple.shade700,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // دالة لعرض التغذية الراجعة للطالب
  void _showFeedback(BuildContext context, bool isCorrect, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isCorrect ? Icons.check_circle : Icons.error,
              color: Colors.white,
            ),
            const SizedBox(width: 8),
            Text(message),
          ],
        ),
        backgroundColor: isCorrect ? Colors.green : Colors.red,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
