import 'package:flutter/material.dart';
import 'dart:ui' as ui;

class DrawingGameScreen extends StatefulWidget {
  const DrawingGameScreen({Key? key}) : super(key: key);

  @override
  _DrawingGameScreenState createState() => _DrawingGameScreenState();
}

class _DrawingGameScreenState extends State<DrawingGameScreen> {
  Color selectedColor = Colors.black;
  double strokeWidth = 5.0;
  List<DrawingPoint?> points = [];
  bool isErasing = false;
  String currentDrawingPrompt = "قطة";
  int currentLevel = 1;
  int score = 0;
  
  final List<String> drawingPrompts = [
    "قطة",
    "كلب",
    "شجرة",
    "منزل",
    "سيارة",
    "طائرة",
    "شمس",
    "قمر",
    "نجمة",
    "سمكة",
    "فيل",
    "زرافة",
    "أسد",
    "تفاحة",
    "موزة"
  ];
  
  final List<Color> availableColors = [
    Colors.black,
    Colors.red,
    Colors.blue,
    Colors.green,
    Colors.yellow,
    Colors.orange,
    Colors.purple,
    Colors.pink,
    Colors.brown,
    Colors.teal,
  ];

  @override
  void initState() {
    super.initState();
    _selectRandomPrompt();
  }
  
  void _selectRandomPrompt() {
    final index = DateTime.now().millisecondsSinceEpoch % drawingPrompts.length;
    setState(() {
      currentDrawingPrompt = drawingPrompts[index];
    });
  }
  
  void _completeDrawing() {
    setState(() {
      score += 10 * currentLevel;
      currentLevel++;
      points.clear();
      _selectRandomPrompt();
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('أحسنت! لقد رسمت $currentDrawingPrompt بشكل رائع!'),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لعبة الرسم والتلوين'),
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: _showHelpDialog,
            tooltip: 'المساعدة',
          ),
        ],
      ),
      body: Column(
        children: [
          _buildPromptAndScore(),
          Expanded(
            child: GestureDetector(
              onPanStart: (details) {
                setState(() {
                  points.add(
                    DrawingPoint(
                      details.localPosition,
                      Paint()
                        ..color = isErasing ? Colors.white : selectedColor
                        ..strokeCap = StrokeCap.round
                        ..strokeWidth = strokeWidth
                        ..blendMode = isErasing ? BlendMode.clear : BlendMode.srcOver,
                    ),
                  );
                });
              },
              onPanUpdate: (details) {
                setState(() {
                  points.add(
                    DrawingPoint(
                      details.localPosition,
                      Paint()
                        ..color = isErasing ? Colors.white : selectedColor
                        ..strokeCap = StrokeCap.round
                        ..strokeWidth = strokeWidth
                        ..blendMode = isErasing ? BlendMode.clear : BlendMode.srcOver,
                    ),
                  );
                });
              },
              onPanEnd: (details) {
                setState(() {
                  points.add(null);
                });
              },
              child: Container(
                margin: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 1,
                      blurRadius: 3,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CustomPaint(
                    painter: DrawingPainter(points),
                    child: Container(),
                  ),
                ),
              ),
            ),
          ),
          _buildColorPalette(),
          _buildToolbar(),
        ],
      ),
    );
  }
  
  Widget _buildPromptAndScore() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      color: Colors.blue.shade50,
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ارسم:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  currentDrawingPrompt,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                'المستوى: $currentLevel',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'النقاط: $score',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildColorPalette() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: availableColors.map((color) {
          return GestureDetector(
            onTap: () {
              setState(() {
                selectedColor = color;
                isErasing = false;
              });
            },
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                border: Border.all(
                  color: selectedColor == color ? Colors.blue : Colors.grey,
                  width: selectedColor == color ? 3 : 1,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
  
  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildToolButton(
            icon: Icons.brush,
            label: 'فرشاة',
            isSelected: !isErasing,
            onPressed: () {
              setState(() {
                isErasing = false;
              });
            },
          ),
          _buildToolButton(
            icon: Icons.cleaning_services,
            label: 'ممحاة',
            isSelected: isErasing,
            onPressed: () {
              setState(() {
                isErasing = true;
              });
            },
          ),
          _buildToolButton(
            icon: Icons.clear,
            label: 'مسح الكل',
            onPressed: () {
              setState(() {
                points.clear();
              });
            },
          ),
          _buildToolButton(
            icon: Icons.check_circle,
            label: 'اكتمل',
            color: Colors.green,
            onPressed: _completeDrawing,
          ),
        ],
      ),
    );
  }
  
  Widget _buildToolButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    bool isSelected = false,
    Color? color,
  }) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: isSelected ? Colors.blue.shade100 : null,
            shape: const CircleBorder(),
            padding: const EdgeInsets.all(16),
          ),
          child: Icon(
            icon,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }
  
  void _showHelpDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('كيفية اللعب'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('• ارسم الصورة المطلوبة في المربع الأبيض'),
            SizedBox(height: 8),
            Text('• استخدم الألوان المختلفة من لوحة الألوان'),
            SizedBox(height: 8),
            Text('• يمكنك استخدام الممحاة لمسح أجزاء من الرسم'),
            SizedBox(height: 8),
            Text('• اضغط على "مسح الكل" لبدء رسم جديد'),
            SizedBox(height: 8),
            Text('• عندما تنتهي من الرسم، اضغط على "اكتمل"'),
            SizedBox(height: 8),
            Text('• ستحصل على نقاط وستنتقل إلى المستوى التالي'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('فهمت'),
          ),
        ],
      ),
    );
  }
}

class DrawingPainter extends CustomPainter {
  final List<DrawingPoint?> points;

  DrawingPainter(this.points);

  @override
  void paint(Canvas canvas, Size size) {
    for (int i = 0; i < points.length - 1; i++) {
      if (points[i] != null && points[i + 1] != null) {
        canvas.drawLine(points[i]!.position, points[i + 1]!.position, points[i]!.paint);
      } else if (points[i] != null && points[i + 1] == null) {
        canvas.drawPoints(ui.PointMode.points, [points[i]!.position], points[i]!.paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class DrawingPoint {
  final Offset position;
  final Paint paint;

  DrawingPoint(this.position, this.paint);
}
