import 'package:flutter/material.dart';
import 'package:kids_education_app/screens/login_screen.dart';
import 'package:kids_education_app/screens/home_screen.dart';
import 'package:kids_education_app/screens/splash_screen.dart';
import 'package:kids_education_app/screens/courses_screen.dart';
import 'package:kids_education_app/screens/games_screen.dart';
import 'package:kids_education_app/screens/profile_screen.dart';
import 'package:kids_education_app/screens/settings_screen.dart';
import 'package:kids_education_app/screens/help_screen.dart';
import 'package:kids_education_app/screens/achievements_screen.dart';
import 'package:kids_education_app/screens/friends_screen.dart';
import 'package:kids_education_app/screens/english_course_screen.dart';
import 'package:kids_education_app/screens/math_course_screen.dart';
import 'package:kids_education_app/screens/drawing_game_screen.dart';
import 'package:kids_education_app/screens/puzzle_game_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تطبيق تعليمي للأطفال',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Cairo',
        useMaterial3: true,
      ),
      darkTheme: ThemeData.dark(useMaterial3: true),
      themeMode: ThemeMode.light,
      locale: const Locale('ar', 'SA'),
      initialRoute: '/splash',
      routes: {
        '/splash': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/home': (context) => const HomeScreen(),
        '/courses': (context) => const CoursesScreen(),
        '/games': (context) => const GamesScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/settings': (context) => const SettingsScreen(),
        '/help': (context) => const HelpScreen(),
        '/achievements': (context) => const AchievementsScreen(),
        '/friends': (context) => const FriendsScreen(),
        '/english_course': (context) => const EnglishCourseScreen(),
        '/math_course': (context) => const MathCourseScreen(),
        '/drawing_game': (context) => const DrawingGameScreen(),
        '/puzzle_game': (context) => const PuzzleGameScreen(),
      },
    );
  }
}
