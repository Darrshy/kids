import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _soundEnabled = true;
  bool _darkModeEnabled = false;
  String _selectedLanguage = 'العربية';
  double _textSize = 1.0;
  
  final List<String> _availableLanguages = [
    'العربية',
    'English',
    'Français',
    'Español',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإعدادات'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildSectionTitle('الإشعارات والصوت'),
          _buildSettingSwitch(
            'تفعيل الإشعارات',
            'استلام إشعارات عن الدروس الجديدة والتحديثات',
            _notificationsEnabled,
            (value) {
              setState(() {
                _notificationsEnabled = value;
              });
            },
            Icons.notifications,
          ),
          _buildSettingSwitch(
            'تفعيل الأصوات',
            'تشغيل الأصوات أثناء استخدام التطبيق',
            _soundEnabled,
            (value) {
              setState(() {
                _soundEnabled = value;
              });
            },
            Icons.volume_up,
          ),
          const Divider(),
          
          _buildSectionTitle('المظهر'),
          _buildSettingSwitch(
            'الوضع الليلي',
            'استخدام ألوان داكنة للتطبيق',
            _darkModeEnabled,
            (value) {
              setState(() {
                _darkModeEnabled = value;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('سيتم تطبيق الوضع الليلي عند إعادة تشغيل التطبيق'),
                ),
              );
            },
            Icons.dark_mode,
          ),
          _buildTextSizeSlider(),
          const Divider(),
          
          _buildSectionTitle('اللغة'),
          _buildLanguageSelector(),
          const Divider(),
          
          _buildSectionTitle('الخصوصية والأمان'),
          _buildSettingTile(
            'تغيير كلمة المرور',
            'تعديل كلمة المرور الخاصة بك',
            Icons.lock,
            () {
              _showChangePasswordDialog();
            },
          ),
          _buildSettingTile(
            'إعدادات الخصوصية',
            'التحكم في مشاركة البيانات والمعلومات الشخصية',
            Icons.privacy_tip,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('إعدادات الخصوصية قيد التطوير'),
                ),
              );
            },
          ),
          const Divider(),
          
          _buildSectionTitle('عن التطبيق'),
          _buildSettingTile(
            'الإصدار',
            '1.0.0',
            Icons.info,
            null,
          ),
          _buildSettingTile(
            'تقييم التطبيق',
            'شاركنا رأيك في التطبيق',
            Icons.star,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('شكراً لتقييمك للتطبيق!'),
                ),
              );
            },
          ),
          _buildSettingTile(
            'سياسة الخصوصية',
            'قراءة سياسة الخصوصية الخاصة بالتطبيق',
            Icons.policy,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('سياسة الخصوصية قيد التطوير'),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              _showLogoutConfirmationDialog();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('تسجيل الخروج'),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 18 * _textSize,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).primaryColor,
        ),
      ),
    );
  }

  Widget _buildSettingSwitch(
    String title,
    String subtitle,
    bool value,
    Function(bool) onChanged,
    IconData icon,
  ) {
    return ListTile(
      leading: Icon(icon, color: Theme.of(context).primaryColor),
      title: Text(title, style: TextStyle(fontSize: 16 * _textSize)),
      subtitle: Text(subtitle, style: TextStyle(fontSize: 14 * _textSize)),
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: Theme.of(context).primaryColor,
      ),
    );
  }

  Widget _buildSettingTile(
    String title,
    String subtitle,
    IconData icon,
    Function()? onTap,
  ) {
    return ListTile(
      leading: Icon(icon, color: Theme.of(context).primaryColor),
      title: Text(title, style: TextStyle(fontSize: 16 * _textSize)),
      subtitle: Text(subtitle, style: TextStyle(fontSize: 14 * _textSize)),
      trailing: onTap != null ? const Icon(Icons.arrow_forward_ios, size: 16) : null,
      onTap: onTap,
    );
  }

  Widget _buildTextSizeSlider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'حجم النص',
            style: TextStyle(fontSize: 16 * _textSize),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.text_fields, size: 16),
              Expanded(
                child: Slider(
                  value: _textSize,
                  min: 0.8,
                  max: 1.4,
                  divisions: 6,
                  label: _getTextSizeLabel(),
                  onChanged: (value) {
                    setState(() {
                      _textSize = value;
                    });
                  },
                ),
              ),
              const Icon(Icons.text_fields, size: 24),
            ],
          ),
        ],
      ),
    );
  }

  String _getTextSizeLabel() {
    if (_textSize <= 0.8) return 'صغير جداً';
    if (_textSize <= 0.9) return 'صغير';
    if (_textSize <= 1.0) return 'عادي';
    if (_textSize <= 1.1) return 'متوسط';
    if (_textSize <= 1.2) return 'كبير';
    if (_textSize <= 1.3) return 'كبير جداً';
    return 'ضخم';
  }

  Widget _buildLanguageSelector() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'لغة التطبيق',
            style: TextStyle(fontSize: 16 * _textSize),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
            ),
            child: DropdownButton<String>(
              value: _selectedLanguage,
              isExpanded: true,
              underline: const SizedBox(),
              onChanged: (String? newValue) {
                if (newValue != null) {
                  setState(() {
                    _selectedLanguage = newValue;
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('تم تغيير اللغة إلى: $newValue'),
                    ),
                  );
                }
              },
              items: _availableLanguages.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  void _showChangePasswordDialog() {
    final TextEditingController _currentPasswordController = TextEditingController();
    final TextEditingController _newPasswordController = TextEditingController();
    final TextEditingController _confirmPasswordController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تغيير كلمة المرور'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _currentPasswordController,
              decoration: const InputDecoration(
                labelText: 'كلمة المرور الحالية',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _newPasswordController,
              decoration: const InputDecoration(
                labelText: 'كلمة المرور الجديدة',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _confirmPasswordController,
              decoration: const InputDecoration(
                labelText: 'تأكيد كلمة المرور الجديدة',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              if (_newPasswordController.text != _confirmPasswordController.text) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('كلمة المرور الجديدة غير متطابقة'),
                    backgroundColor: Colors.red,
                  ),
                );
                return;
              }
              
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('تم تغيير كلمة المرور بنجاح'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: const Text('تغيير'),
          ),
        ],
      ),
    );
  }

  void _showLogoutConfirmationDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل أنت متأكد من رغبتك في تسجيل الخروج؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/login');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('تسجيل الخروج'),
          ),
        ],
      ),
    );
  }
}
