import 'package:flutter/material.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({Key? key}) : super(key: key);

  @override
  _FriendsScreenState createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  
  final List<Map<String, dynamic>> _friends = [
    {
      'name': 'سارة أحمد',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140048.png',
      'level': 'متقدم',
      'points': 850,
      'isOnline': true,
      'lastActive': 'الآن',
      'achievements': 12,
      'games': ['الرسم', 'الألغاز الحسابية'],
    },
    {
      'name': 'محمد علي',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140037.png',
      'level': 'مبتدئ',
      'points': 320,
      'isOnline': false,
      'lastActive': 'منذ ساعتين',
      'achievements': 5,
      'games': ['الرسم'],
    },
    {
      'name': 'فاطمة محمود',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140047.png',
      'level': 'متوسط',
      'points': 620,
      'isOnline': true,
      'lastActive': 'الآن',
      'achievements': 8,
      'games': ['الألغاز الحسابية', 'كورس اللغة الإنجليزية'],
    },
    {
      'name': 'أحمد خالد',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140051.png',
      'level': 'متقدم',
      'points': 920,
      'isOnline': false,
      'lastActive': 'منذ يوم',
      'achievements': 15,
      'games': ['الرسم', 'الألغاز الحسابية', 'كورس اللغة الإنجليزية'],
    },
    {
      'name': 'نور محمد',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140040.png',
      'level': 'متوسط',
      'points': 580,
      'isOnline': false,
      'lastActive': 'منذ 3 ساعات',
      'achievements': 7,
      'games': ['كورس اللغة الإنجليزية'],
    },
  ];
  
  final List<Map<String, dynamic>> _friendRequests = [
    {
      'name': 'ياسمين محمد',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140042.png',
      'level': 'مبتدئ',
      'points': 250,
    },
    {
      'name': 'عمر أحمد',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140046.png',
      'level': 'متوسط',
      'points': 480,
    },
  ];
  
  final List<Map<String, dynamic>> _suggestedFriends = [
    {
      'name': 'ليلى سعيد',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140049.png',
      'level': 'متقدم',
      'points': 780,
      'mutualFriends': 2,
    },
    {
      'name': 'كريم محمود',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140043.png',
      'level': 'متوسط',
      'points': 550,
      'mutualFriends': 1,
    },
    {
      'name': 'سلمى عادل',
      'avatar': 'https://cdn-icons-png.flaticon.com/512/4140/4140050.png',
      'level': 'مبتدئ',
      'points': 320,
      'mutualFriends': 3,
    },
  ];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الأصدقاء'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'الأصدقاء'),
            Tab(text: 'طلبات الصداقة'),
            Tab(text: 'اقتراحات'),
          ],
        ),
      ),
      body: Column(
        children: [
          _buildSearchBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildFriendsList(),
                _buildFriendRequestsList(),
                _buildSuggestedFriendsList(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddFriendDialog,
        child: const Icon(Icons.person_add),
        tooltip: 'إضافة صديق',
      ),
    );
  }
  
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          hintText: 'البحث عن صديق...',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: IconButton(
            icon: const Icon(Icons.clear),
            onPressed: () {
              _searchController.clear();
            },
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onChanged: (value) {
          // يمكن تنفيذ البحث هنا
          setState(() {});
        },
      ),
    );
  }
  
  Widget _buildFriendsList() {
    final filteredFriends = _searchController.text.isEmpty
        ? _friends
        : _friends.where((friend) => friend['name'].toString().contains(_searchController.text)).toList();
    
    return filteredFriends.isEmpty
        ? const Center(child: Text('لا يوجد أصدقاء'))
        : ListView.builder(
            padding: const EdgeInsets.all(16.0),
            itemCount: filteredFriends.length,
            itemBuilder: (context, index) {
              final friend = filteredFriends[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 16.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: InkWell(
                  onTap: () => _showFriendDetails(friend),
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Stack(
                          children: [
                            CircleAvatar(
                              radius: 30,
                              backgroundImage: NetworkImage(friend['avatar']),
                            ),
                            if (friend['isOnline'])
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: Container(
                                  width: 16,
                                  height: 16,
                                  decoration: BoxDecoration(
                                    color: Colors.green,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Colors.white,
                                      width: 2,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                friend['name'],
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'المستوى: ${friend['level']} • ${friend['points']} نقطة',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[600],
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                friend['isOnline'] ? 'متصل الآن' : 'آخر ظهور: ${friend['lastActive']}',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: friend['isOnline'] ? Colors.green : Colors.grey,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.message),
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('مراسلة ${friend['name']}'),
                                  ),
                                );
                              },
                              tooltip: 'مراسلة',
                            ),
                            IconButton(
                              icon: const Icon(Icons.videogame_asset),
                              onPressed: () {
                                _showPlayGameDialog(friend);
                              },
                              tooltip: 'اللعب معاً',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
  }
  
  Widget _buildFriendRequestsList() {
    return _friendRequests.isEmpty
        ? const Center(child: Text('لا توجد طلبات صداقة'))
        : ListView.builder(
            padding: const EdgeInsets.all(16.0),
            itemCount: _friendRequests.length,
            itemBuilder: (context, index) {
              final request = _friendRequests[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 16.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundImage: NetworkImage(request['avatar']),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              request['name'],
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'المستوى: ${request['level']} • ${request['points']} نقطة',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          ElevatedButton(
                            onPressed: () {
                              setState(() {
                                _friends.add({
                                  'name': request['name'],
                                  'avatar': request['avatar'],
                                  'level': request['level'],
                                  'points': request['points'],
                                  'isOnline': false,
                                  'lastActive': 'منذ قليل',
                                  'achievements': 0,
                                  'games': [],
                                });
                                _friendRequests.removeAt(index);
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('تمت الموافقة على طلب ${request['name']}'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                            ),
                            child: const Text('قبول'),
                          ),
                          const SizedBox(width: 8),
                          OutlinedButton(
                            onPressed: () {
                              setState(() {
                                _friendRequests.removeAt(index);
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('تم رفض طلب ${request['name']}'),
                                ),
                              );
                            },
                            child: const Text('رفض'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }
  
  Widget _buildSuggestedFriendsList() {
    return _suggestedFriends.isEmpty
        ? const Center(child: Text('لا توجد اقتراحات'))
        : ListView.builder(
            padding: const EdgeInsets.all(16.0),
            itemCount: _suggestedFriends.length,
            itemBuilder: (context, index) {
              final suggestion = _suggestedFriends[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 16.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundImage: NetworkImage(suggestion['avatar']),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              suggestion['name'],
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'المستوى: ${suggestion['level']} • ${suggestion['points']} نقطة',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[600],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '${suggestion['mutualFriends']} أصدقاء مشتركين',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.blue,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _friends.add({
                              'name': suggestion['name'],
                              'avatar': suggestion['avatar'],
                              'level': suggestion['level'],
                              'points': suggestion['points'],
                              'isOnline': false,
                              'lastActive': 'منذ قليل',
                              'achievements': 0,
                              'games': [],
                            });
                            _suggestedFriends.removeAt(index);
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('تمت إضافة ${suggestion['name']} كصديق'),
                              backgroundColor: Colors.green,
                            ),
                          );
                        },
                        child: const Text('إضافة'),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }
  
  void _showFriendDetails(Map<String, dynamic> friend) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(friend['name']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundImage: NetworkImage(friend['avatar']),
              ),
            ),
            const SizedBox(height: 16),
            Text('المستوى: ${friend['level']}'),
            const SizedBox(height: 8),
            Text('النقاط: ${friend['points']}'),
            const SizedBox(height: 8),
            Text('الإنجازات: ${friend['achievements']}'),
            const SizedBox(height: 8),
            const Text('الألعاب المفضلة:'),
            ...friend['games'].map<Widget>((game) => Padding(
              padding: const EdgeInsets.only(left: 16.0, top: 4.0),
              child: Row(
                children: [
                  const Icon(Icons.check, size: 16),
                  const SizedBox(width: 8),
                  Text(game),
                ],
              ),
            )).toList(),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إغلاق'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showPlayGameDialog(friend);
            },
            child: const Text('اللعب معاً'),
          ),
        ],
      ),
    );
  }
  
  void _showPlayGameDialog(Map<String, dynamic> friend) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('اللعب مع ${friend['name']}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('اختر لعبة للعب معاً:'),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.brush),
              title: const Text('لعبة الرسم'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('تم إرسال دعوة للعب الرسم مع ${friend['name']}'),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.extension),
              title: const Text('الألغاز الحسابية'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('تم إرسال دعوة للعب الألغاز الحسابية مع ${friend['name']}'),
                  ),
                );
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
        ],
      ),
    );
  }
  
  void _showAddFriendDialog() {
    final TextEditingController _usernameController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إضافة صديق'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(
                labelText: 'اسم المستخدم أو البريد الإلكتروني',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              if (_usernameController.text.isNotEmpty) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('تم إرسال طلب صداقة إلى ${_usernameController.text}'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            child: const Text('إرسال طلب'),
          ),
        ],
      ),
    );
  }
}
