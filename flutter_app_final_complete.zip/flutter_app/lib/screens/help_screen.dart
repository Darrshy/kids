import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المساعدة والدعم'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildHelpSection(
            context,
            'الأسئلة الشائعة',
            Icons.question_answer,
            Colors.blue,
            _buildFAQs(),
          ),
          const SizedBox(height: 16),
          _buildHelpSection(
            context,
            'دليل استخدام التطبيق',
            Icons.menu_book,
            Colors.green,
            _buildUserGuide(),
          ),
          const SizedBox(height: 16),
          _buildHelpSection(
            context,
            'الدعم الفني',
            Icons.support_agent,
            Colors.orange,
            _buildTechnicalSupport(context),
          ),
          const SizedBox(height: 16),
          _buildHelpSection(
            context,
            'حول التطبيق',
            Icons.info,
            Colors.purple,
            _buildAboutApp(),
          ),
        ],
      ),
    );
  }

  Widget _buildHelpSection(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    Widget content,
  ) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ExpansionTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.2),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: content,
          ),
        ],
      ),
    );
  }

  Widget _buildFAQs() {
    final List<Map<String, String>> faqs = [
      {
        'question': 'كيف يمكنني تسجيل الدخول؟',
        'answer': 'يمكنك تسجيل الدخول باستخدام اسم المستخدم وكلمة المرور التي قمت بإنشائها عند التسجيل. إذا نسيت كلمة المرور، يمكنك استخدام خيار "نسيت كلمة المرور" لإعادة تعيينها.'
      },
      {
        'question': 'كيف يمكنني متابعة تقدم طفلي؟',
        'answer': 'يمكنك متابعة تقدم طفلك من خلال تسجيل الدخول كولي أمر، ثم الانتقال إلى قسم "التقارير" حيث ستجد معلومات مفصلة عن أداء طفلك في الكورسات والألعاب المختلفة.'
      },
      {
        'question': 'كيف يمكنني إضافة محتوى تعليمي جديد؟',
        'answer': 'يمكن للمعلمين إضافة محتوى تعليمي جديد من خلال تسجيل الدخول كمعلم، ثم الانتقال إلى قسم "إدارة المحتوى" واتباع الخطوات لإضافة دروس أو اختبارات جديدة.'
      },
      {
        'question': 'هل يمكنني استخدام التطبيق بدون اتصال بالإنترنت؟',
        'answer': 'نعم، يمكنك تنزيل بعض الدروس والألعاب للاستخدام دون اتصال بالإنترنت. انتقل إلى قسم "التنزيلات" واختر المحتوى الذي ترغب في تنزيله.'
      },
      {
        'question': 'كيف يمكنني تغيير لغة التطبيق؟',
        'answer': 'يمكنك تغيير لغة التطبيق من خلال الانتقال إلى "الإعدادات" ثم اختيار "اللغة" واختيار اللغة المفضلة لديك.'
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: faqs.map((faq) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                faq['question']!,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                faq['answer']!,
                style: const TextStyle(fontSize: 14),
              ),
              const Divider(),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildUserGuide() {
    final List<Map<String, dynamic>> guideItems = [
      {
        'title': 'الشاشة الرئيسية',
        'icon': Icons.home,
        'content': 'تعرض الشاشة الرئيسية الكورسات والألعاب المقترحة لك بناءً على مستواك واهتماماتك. يمكنك النقر على أي عنصر للانتقال إليه مباشرة.'
      },
      {
        'title': 'قسم الكورسات',
        'icon': Icons.school,
        'content': 'يحتوي على كورسات تعليمية مختلفة مثل الحساب الذهني واللغة الإنجليزية. اختر الكورس الذي ترغب في دراسته وابدأ التعلم خطوة بخطوة.'
      },
      {
        'title': 'قسم الألعاب',
        'icon': Icons.games,
        'content': 'يضم مجموعة متنوعة من الألعاب التعليمية والذهنية والإبداعية. استمتع باللعب وتعلم مهارات جديدة في نفس الوقت.'
      },
      {
        'title': 'الملف الشخصي',
        'icon': Icons.person,
        'content': 'يعرض معلوماتك الشخصية وإنجازاتك وتقدمك في الكورسات المختلفة. يمكنك تغيير صورتك الشخصية بالنقر عليها.'
      },
      {
        'title': 'الإعدادات',
        'icon': Icons.settings,
        'content': 'تتيح لك تخصيص التطبيق حسب تفضيلاتك، مثل تغيير اللغة وإعدادات الإشعارات والصوت والمظهر.'
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: guideItems.map((item) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(item['icon'], color: Colors.green),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['title'],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item['content'],
                      style: const TextStyle(fontSize: 14),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTechnicalSupport(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'هل تواجه مشكلة في استخدام التطبيق؟',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 16),
        ListTile(
          leading: const Icon(Icons.email, color: Colors.orange),
          title: const Text('راسلنا عبر البريد الإلكتروني'),
          subtitle: const Text('support@kidsapp.com'),
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم فتح تطبيق البريد الإلكتروني'),
              ),
            );
          },
        ),
        ListTile(
          leading: const Icon(Icons.phone, color: Colors.orange),
          title: const Text('اتصل بنا'),
          subtitle: const Text('+123456789'),
          onTap: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم فتح تطبيق الهاتف'),
              ),
            );
          },
        ),
        ListTile(
          leading: const Icon(Icons.chat, color: Colors.orange),
          title: const Text('الدردشة المباشرة'),
          subtitle: const Text('متاحة من 9 صباحاً حتى 5 مساءً'),
          onTap: () {
            _showChatDialog(context);
          },
        ),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: () {
            _showReportProblemDialog(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange,
            foregroundColor: Colors.white,
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.report_problem),
              SizedBox(width: 8),
              Text('الإبلاغ عن مشكلة'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAboutApp() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Center(
          child: Column(
            children: [
              Icon(Icons.school, size: 64, color: Colors.purple),
              SizedBox(height: 8),
              Text(
                'تطبيق تعليمي للأطفال',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'الإصدار 1.0.0',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'تطبيق تعليمي شامل للأطفال يهدف إلى تقديم تجربة تعليمية ممتعة ومفيدة. يتضمن التطبيق كورسات تعليمية في الحساب الذهني واللغة الإنجليزية، بالإضافة إلى مجموعة متنوعة من الألعاب التعليمية والذهنية والإبداعية.',
          style: TextStyle(fontSize: 14),
          textAlign: TextAlign.justify,
        ),
        const SizedBox(height: 16),
        const Text(
          'المطورون:',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 8),
        const ListTile(
          leading: Icon(Icons.code, color: Colors.purple),
          title: Text('فريق تطوير التطبيقات التعليمية'),
          subtitle: Text('جميع الحقوق محفوظة © 2025'),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildSocialButton(Icons.language, 'الموقع'),
            _buildSocialButton(Icons.facebook, 'فيسبوك'),
            _buildSocialButton(Icons.telegram, 'تلجرام'),
            _buildSocialButton(Icons.email, 'البريد'),
          ],
        ),
      ],
    );
  }

  Widget _buildSocialButton(IconData icon, String label) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon),
          onPressed: () {},
          color: Colors.purple,
        ),
        Text(
          label,
          style: const TextStyle(fontSize: 12),
        ),
      ],
    );
  }

  void _showChatDialog(BuildContext context) {
    final TextEditingController _messageController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.support_agent, color: Colors.orange),
            SizedBox(width: 8),
            Text('الدردشة مع الدعم الفني'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'مرحباً! كيف يمكنني مساعدتك اليوم؟',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _messageController,
              decoration: const InputDecoration(
                labelText: 'اكتب رسالتك هنا',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              if (_messageController.text.isNotEmpty) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم إرسال رسالتك إلى فريق الدعم الفني. سنرد عليك قريباً.'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
            child: const Text('إرسال'),
          ),
        ],
      ),
    );
  }

  void _showReportProblemDialog(BuildContext context) {
    final TextEditingController _problemController = TextEditingController();
    String _selectedProblemType = 'مشكلة فنية';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.report_problem, color: Colors.red),
            SizedBox(width: 8),
            Text('الإبلاغ عن مشكلة'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('نوع المشكلة:'),
            const SizedBox(height: 8),
            StatefulBuilder(
              builder: (context, setState) {
                return DropdownButton<String>(
                  isExpanded: true,
                  value: _selectedProblemType,
                  items: const [
                    DropdownMenuItem(
                      value: 'مشكلة فنية',
                      child: Text('مشكلة فنية'),
                    ),
                    DropdownMenuItem(
                      value: 'مشكلة في المحتوى',
                      child: Text('مشكلة في المحتوى'),
                    ),
                    DropdownMenuItem(
                      value: 'اقتراح تحسين',
                      child: Text('اقتراح تحسين'),
                    ),
                    DropdownMenuItem(
                      value: 'أخرى',
                      child: Text('أخرى'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _selectedProblemType = value;
                      });
                    }
                  },
                );
              },
            ),
            const SizedBox(height: 16),
            const Text('وصف المشكلة:'),
            const SizedBox(height: 8),
            TextField(
              controller: _problemController,
              decoration: const InputDecoration(
                hintText: 'اشرح المشكلة بالتفصيل...',
                border: OutlineInputBorder(),
              ),
              maxLines: 5,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              if (_problemController.text.isNotEmpty) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم إرسال بلاغك بنجاح. سنعمل على حل المشكلة في أقرب وقت ممكن.'),
                    backgroundColor: Colors.green,
                  ),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('يرجى كتابة وصف للمشكلة'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('إرسال البلاغ'),
          ),
        ],
      ),
    );
  }
}
