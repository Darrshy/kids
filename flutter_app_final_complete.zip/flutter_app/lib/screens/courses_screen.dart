import 'package:flutter/material.dart';
import 'package:kids_education_app/screens/english_course_screen.dart';
import 'package:kids_education_app/screens/math_course_screen.dart';

class CoursesScreen extends StatefulWidget {
  const CoursesScreen({Key? key}) : super(key: key);

  @override
  _CoursesScreenState createState() => _CoursesScreenState();
}

class _CoursesScreenState extends State<CoursesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الكورسات التعليمية'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'الحساب الذهني'),
            Tab(text: 'اللغة الإنجليزية'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildMathCourses(),
          _buildEnglishCourses(),
        ],
      ),
    );
  }

  Widget _buildMathCourses() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCourseHeader(
            'كورس الحساب الذهني',
            'تعلم أساسيات الحساب الذهني وتقنيات متقدمة',
            'https://cdn-icons-png.flaticon.com/512/2490/2490396.png',
          ),
          const SizedBox(height: 24),
          _buildCourseCard(
            'الوحدة الأولى: أساسيات الحساب الذهني',
            'تعلم المبادئ الأساسية للحساب الذهني وفوائده',
            '2 دروس',
            0.7,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MathCourseScreen()),
              );
            },
          ),
          _buildCourseCard(
            'الوحدة الثانية: تقنيات متقدمة في الحساب الذهني',
            'تعلم استراتيجيات الضرب الذهني وتمارين سرعة الحساب',
            '2 دروس',
            0.3,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MathCourseScreen()),
              );
            },
          ),
          _buildCourseCard(
            'الوحدة الثالثة: تطبيقات عملية',
            'تطبيق مهارات الحساب الذهني في الحياة اليومية',
            '3 دروس',
            0.0,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('سيتم إضافة هذه الوحدة قريباً'),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          _buildCourseStats(),
        ],
      ),
    );
  }

  Widget _buildEnglishCourses() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCourseHeader(
            'كورس تأسيس اللغة الإنجليزية',
            'تعلم أساسيات اللغة الإنجليزية من الصفر',
            'https://cdn-icons-png.flaticon.com/512/1791/1791336.png',
          ),
          const SizedBox(height: 24),
          _buildCourseCard(
            'الوحدة الأولى: الحروف والأصوات',
            'تعلم الحروف الإنجليزية ونطقها الصحيح',
            '2 دروس',
            0.8,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const EnglishCourseScreen()),
              );
            },
          ),
          _buildCourseCard(
            'الوحدة الثانية: الكلمات والجمل البسيطة',
            'تعلم التحية والتعارف والألوان والأرقام',
            '2 دروس',
            0.5,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const EnglishCourseScreen()),
              );
            },
          ),
          _buildCourseCard(
            'الوحدة الثالثة: المحادثات اليومية',
            'تعلم المحادثات اليومية البسيطة',
            '3 دروس',
            0.0,
            () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('سيتم إضافة هذه الوحدة قريباً'),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          _buildCourseStats(),
        ],
      ),
    );
  }

  Widget _buildCourseHeader(String title, String description, String imageUrl) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              imageUrl,
              width: 80,
              height: 80,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildInfoChip('4 وحدات'),
                    const SizedBox(width: 8),
                    _buildInfoChip('12 درس'),
                    const SizedBox(width: 8),
                    _buildInfoChip('2 ساعة'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.shade100),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          color: Colors.blue.shade700,
        ),
      ),
    );
  }

  Widget _buildCourseCard(
    String title,
    String description,
    String lessons,
    double progress,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    lessons,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.blue.shade700,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              description,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress,
                      backgroundColor: Colors.grey.shade200,
                      color: progress > 0 ? Colors.green : Colors.grey,
                      minHeight: 8,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '${(progress * 100).toInt()}%',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: progress > 0 ? Colors.green : Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                  onPressed: onTap,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: progress > 0 ? Colors.blue : Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  ),
                  child: Text(
                    progress > 0 ? 'استكمال التعلم' : 'ابدأ التعلم',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCourseStats() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'إحصائيات التقدم',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem('الدروس المكتملة', '4/12', Icons.check_circle, Colors.green),
              _buildStatItem('الوقت المستغرق', '45 دقيقة', Icons.access_time, Colors.orange),
              _buildStatItem('النقاط المكتسبة', '120', Icons.star, Colors.amber),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: color,
            size: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
