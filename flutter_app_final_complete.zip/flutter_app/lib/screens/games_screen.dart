import 'package:flutter/material.dart';
import 'package:kids_education_app/screens/drawing_game_screen.dart';
import 'package:kids_education_app/screens/english_course_screen.dart';
import 'package:kids_education_app/screens/math_course_screen.dart';
import 'package:kids_education_app/screens/puzzle_game_screen.dart';

class GamesScreen extends StatefulWidget {
  const GamesScreen({Key? key}) : super(key: key);

  @override
  _GamesScreenState createState() => _GamesScreenState();
}

class _GamesScreenState extends State<GamesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الألعاب الذكية'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'الألعاب التعليمية'),
            Tab(text: 'الألعاب الذهنية'),
            Tab(text: 'الألعاب الإبداعية'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildEducationalGames(),
          _buildMentalGames(),
          _buildCreativeGames(),
        ],
      ),
    );
  }

  Widget _buildEducationalGames() {
    return GridView.count(
      crossAxisCount: 2,
      padding: const EdgeInsets.all(16),
      childAspectRatio: 0.8,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      children: [
        _buildGameCard(
          'الحروف الإنجليزية',
          'تعلم الحروف الإنجليزية بطريقة ممتعة',
          'https://cdn-icons-png.flaticon.com/512/1791/1791336.png',
          Colors.blue.shade100,
          () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const EnglishCourseScreen()),
            );
          },
        ),
        _buildGameCard(
          'الحساب الذهني',
          'تدرب على الحساب الذهني بطريقة ممتعة',
          'https://cdn-icons-png.flaticon.com/512/2490/2490396.png',
          Colors.green.shade100,
          () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const MathCourseScreen()),
            );
          },
        ),
        _buildGameCard(
          'الكلمات المتقاطعة',
          'اختبر مفرداتك اللغوية',
          'https://cdn-icons-png.flaticon.com/512/1048/1048949.png',
          Colors.orange.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
        _buildGameCard(
          'العلوم للأطفال',
          'تعلم العلوم بطريقة ممتعة',
          'https://cdn-icons-png.flaticon.com/512/1048/1048966.png',
          Colors.purple.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildMentalGames() {
    return GridView.count(
      crossAxisCount: 2,
      padding: const EdgeInsets.all(16),
      childAspectRatio: 0.8,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      children: [
        _buildGameCard(
          'الألغاز الحسابية',
          'اختبر مهاراتك في الحساب الذهني',
          'https://cdn-icons-png.flaticon.com/512/1048/1048969.png',
          Colors.yellow.shade100,
          () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const PuzzleGameScreen()),
            );
          },
        ),
        _buildGameCard(
          'الذاكرة',
          'اختبر قوة ذاكرتك',
          'https://cdn-icons-png.flaticon.com/512/1048/1048930.png',
          Colors.teal.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
        _buildGameCard(
          'المتاهة',
          'اعثر على الطريق الصحيح',
          'https://cdn-icons-png.flaticon.com/512/1048/1048953.png',
          Colors.indigo.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
        _buildGameCard(
          'الألغاز المنطقية',
          'حل الألغاز المنطقية',
          'https://cdn-icons-png.flaticon.com/512/1048/1048967.png',
          Colors.red.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildCreativeGames() {
    return GridView.count(
      crossAxisCount: 2,
      padding: const EdgeInsets.all(16),
      childAspectRatio: 0.8,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      children: [
        _buildGameCard(
          'الرسم والتلوين',
          'استمتع بالرسم والتلوين مع تحديات مختلفة',
          'https://cdn-icons-png.flaticon.com/512/1048/1048927.png',
          Colors.pink.shade100,
          () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const DrawingGameScreen()),
            );
          },
        ),
        _buildGameCard(
          'تصميم الشخصيات',
          'صمم شخصيتك الكرتونية المفضلة',
          'https://cdn-icons-png.flaticon.com/512/1048/1048964.png',
          Colors.cyan.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
        _buildGameCard(
          'الموسيقى',
          'اعزف وتعلم الموسيقى',
          'https://cdn-icons-png.flaticon.com/512/1048/1048947.png',
          Colors.amber.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
        _buildGameCard(
          'القصص التفاعلية',
          'شارك في صنع قصتك الخاصة',
          'https://cdn-icons-png.flaticon.com/512/1048/1048950.png',
          Colors.deepPurple.shade100,
          () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('سيتم إضافة هذه اللعبة قريباً'),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildGameCard(
    String title,
    String description,
    String imageUrl,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 1,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
              child: Image.network(
                imageUrl,
                height: 120,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.black54,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
