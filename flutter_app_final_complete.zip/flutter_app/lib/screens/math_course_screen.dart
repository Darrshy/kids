import 'package:flutter/material.dart';

class MathCourseScreen extends StatefulWidget {
  const MathCourseScreen({Key? key}) : super(key: key);

  @override
  _MathCourseScreenState createState() => _MathCourseScreenState();
}

class _MathCourseScreenState extends State<MathCourseScreen> {
  final List<Map<String, dynamic>> _units = [
    {
      'title': 'الوحدة الأولى: أساسيات الحساب الذهني',
      'description': 'تعلم أساسيات الحساب الذهني والعمليات الحسابية',
      'progress': 0.7,
      'lessons': [
        {
          'title': 'الدرس الأول: الجمع السريع',
          'description': 'تعلم طرق الجمع السريع ذهنياً',
          'duration': '25 دقيقة',
          'completed': true,
        },
        {
          'title': 'الدرس الثاني: الطرح السريع',
          'description': 'تعلم طرق الطرح السريع ذهنياً',
          'duration': '25 دقيقة',
          'completed': true,
        },
      ],
    },
    {
      'title': 'الوحدة الثانية: العمليات المتقدمة',
      'description': 'تعلم الضرب والقسمة ذهنياً',
      'progress': 0.3,
      'lessons': [
        {
          'title': 'الدرس الأول: الضرب السريع',
          'description': 'تعلم طرق الضرب السريع ذهنياً',
          'duration': '30 دقيقة',
          'completed': true,
        },
        {
          'title': 'الدرس الثاني: القسمة السريعة',
          'description': 'تعلم طرق القسمة السريعة ذهنياً',
          'duration': '30 دقيقة',
          'completed': false,
        },
      ],
    },
  ];

  int _selectedUnitIndex = 0;
  int _selectedLessonIndex = 0;
  bool _isLessonView = false;
  
  // متغيرات للتمارين التفاعلية
  int? _selectedAnswer;
  List<int> _selectedNumbers = [];
  int _score = 0;
  int _currentQuestionIndex = 0;
  bool _quizCompleted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isLessonView
            ? _units[_selectedUnitIndex]['lessons'][_selectedLessonIndex]['title']
            : 'كورس الحساب الذهني'),
        leading: _isLessonView
            ? IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () {
                  setState(() {
                    _isLessonView = false;
                  });
                },
              )
            : null,
      ),
      body: _isLessonView
          ? _buildLessonContent()
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCourseHeader(),
                  const SizedBox(height: 24),
                  ...List.generate(
                    _units.length,
                    (index) => _buildUnitCard(index),
                  ),
                  const SizedBox(height: 24),
                  _buildCourseStats(),
                ],
              ),
            ),
    );
  }

  Widget _buildCourseHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              'https://cdn-icons-png.flaticon.com/512/2490/2490315.png',
              width: 80,
              height: 80,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'كورس الحساب الذهني',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'تعلم إجراء العمليات الحسابية ذهنياً بسرعة ودقة',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _buildInfoChip('${_getTotalUnits()} وحدات'),
                    const SizedBox(width: 8),
                    _buildInfoChip('${_getTotalLessons()} درس'),
                    const SizedBox(width: 8),
                    _buildInfoChip('${_getTotalDuration()} دقيقة'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.shade100),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          color: Colors.blue.shade700,
        ),
      ),
    );
  }

  Widget _buildUnitCard(int unitIndex) {
    final unit = _units[unitIndex];
    final progress = unit['progress'] as double;
    final lessons = unit['lessons'] as List<Map<String, dynamic>>;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        unit['title'],
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${lessons.length} دروس',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.blue.shade700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  unit['description'],
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: progress,
                          backgroundColor: Colors.grey.shade200,
                          color: progress > 0 ? Colors.blue : Colors.grey,
                          minHeight: 8,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${(progress * 100).toInt()}%',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: progress > 0 ? Colors.blue : Colors.grey,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: lessons.length,
            separatorBuilder: (context, index) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final lesson = lessons[index];
              return ListTile(
                title: Text(
                  lesson['title'],
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: lesson['completed'] ? Colors.black : Colors.black54,
                  ),
                ),
                subtitle: Text(
                  lesson['description'],
                  style: TextStyle(
                    fontSize: 12,
                    color: lesson['completed'] ? Colors.black54 : Colors.black38,
                  ),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      lesson['duration'],
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (lesson['completed'])
                      const Icon(
                        Icons.check_circle,
                        color: Colors.blue,
                        size: 20,
                      )
                    else
                      Icon(
                        Icons.play_circle_fill,
                        color: Colors.blue.shade300,
                        size: 20,
                      ),
                  ],
                ),
                onTap: () {
                  setState(() {
                    _selectedUnitIndex = unitIndex;
                    _selectedLessonIndex = index;
                    _isLessonView = true;
                    
                    // إعادة تعيين متغيرات التمارين عند فتح درس جديد
                    _selectedAnswer = null;
                    _selectedNumbers = [];
                    _score = 0;
                    _currentQuestionIndex = 0;
                    _quizCompleted = false;
                  });
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildLessonContent() {
    final lesson = _units[_selectedUnitIndex]['lessons'][_selectedLessonIndex];
    final isFirstLesson = _selectedUnitIndex == 0 && _selectedLessonIndex == 0;
    final isSecondLesson = _selectedUnitIndex == 0 && _selectedLessonIndex == 1;
    final isThirdLesson = _selectedUnitIndex == 1 && _selectedLessonIndex == 0;
    final isFourthLesson = _selectedUnitIndex == 1 && _selectedLessonIndex == 1;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.blue.shade200),
                  ),
                  child: Text(
                    '${_selectedLessonIndex + 1}',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade700,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        lesson['title'],
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        lesson['description'],
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          if (isFirstLesson) _buildFirstLessonContent(),
          if (isSecondLesson) _buildSecondLessonContent(),
          if (isThirdLesson) _buildThirdLessonContent(),
          if (isFourthLesson) _buildFourthLessonContent(),
          const SizedBox(height: 24),
          _buildLessonNavigation(),
        ],
      ),
    );
  }

  Widget _buildFirstLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'الجمع السريع',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'في هذا الدرس سنتعلم طرق الجمع السريع ذهنياً. هناك عدة استراتيجيات يمكن استخدامها لإجراء عمليات الجمع بسرعة ودقة دون الحاجة إلى الورقة والقلم.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        _buildStrategyCard(
          title: 'استراتيجية التقريب للعدد الأقرب للعشرة',
          description: 'تقريب أحد الأعداد للعشرة الأقرب ثم إجراء التعديل اللازم.',
          example: '8 + 7 = 8 + (2 + 5) = (8 + 2) + 5 = 10 + 5 = 15',
          icon: Icons.add_circle,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية تكوين العشرة',
          description: 'تحليل أحد الأعداد بحيث يكون مع العدد الآخر عشرة كاملة.',
          example: '9 + 6 = 9 + (1 + 5) = (9 + 1) + 5 = 10 + 5 = 15',
          icon: Icons.grid_on,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية المضاعفات',
          description: 'استخدام مضاعفات الأعداد لتسهيل عملية الجمع.',
          example: '6 + 7 = 6 + 6 + 1 = 12 + 1 = 13',
          icon: Icons.repeat,
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: أجب عن أسئلة الجمع التالية',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildQuizCard(
          questions: [
            {
              'question': '8 + 7 = ?',
              'options': [13, 14, 15, 16],
              'correctAnswer': 15,
            },
            {
              'question': '9 + 6 = ?',
              'options': [13, 14, 15, 16],
              'correctAnswer': 15,
            },
            {
              'question': '7 + 8 = ?',
              'options': [13, 14, 15, 16],
              'correctAnswer': 15,
            },
            {
              'question': '6 + 9 = ?',
              'options': [13, 14, 15, 16],
              'correctAnswer': 15,
            },
            {
              'question': '5 + 8 = ?',
              'options': [11, 12, 13, 14],
              'correctAnswer': 13,
            },
          ],
        ),
      ],
    );
  }

  Widget _buildSecondLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'الطرح السريع',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'في هذا الدرس سنتعلم طرق الطرح السريع ذهنياً. هناك عدة استراتيجيات يمكن استخدامها لإجراء عمليات الطرح بسرعة ودقة دون الحاجة إلى الورقة والقلم.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        _buildStrategyCard(
          title: 'استراتيجية العد التنازلي',
          description: 'العد التنازلي من العدد الأكبر بمقدار العدد الأصغر.',
          example: '15 - 7 = 15, 14, 13, 12, 11, 10, 9, 8 = 8',
          icon: Icons.arrow_downward,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية الفرق من العشرة',
          description: 'استخدام العشرة كنقطة مرجعية لإجراء عملية الطرح.',
          example: '15 - 7 = 15 - 5 - 2 = 10 - 2 = 8',
          icon: Icons.remove_circle,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية الإضافة للوصول',
          description: 'إضافة أعداد للعدد الأصغر للوصول إلى العدد الأكبر.',
          example: '15 - 7 = 7 + ? = 15, إذاً 7 + 8 = 15، فالجواب هو 8',
          icon: Icons.add_circle_outline,
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: أجب عن أسئلة الطرح التالية',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildQuizCard(
          questions: [
            {
              'question': '15 - 7 = ?',
              'options': [7, 8, 9, 10],
              'correctAnswer': 8,
            },
            {
              'question': '13 - 5 = ?',
              'options': [7, 8, 9, 10],
              'correctAnswer': 8,
            },
            {
              'question': '17 - 9 = ?',
              'options': [6, 7, 8, 9],
              'correctAnswer': 8,
            },
            {
              'question': '20 - 12 = ?',
              'options': [6, 7, 8, 9],
              'correctAnswer': 8,
            },
            {
              'question': '14 - 6 = ?',
              'options': [6, 7, 8, 9],
              'correctAnswer': 8,
            },
          ],
        ),
      ],
    );
  }

  Widget _buildThirdLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'الضرب السريع',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'في هذا الدرس سنتعلم طرق الضرب السريع ذهنياً. هناك عدة استراتيجيات يمكن استخدامها لإجراء عمليات الضرب بسرعة ودقة دون الحاجة إلى الورقة والقلم.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        _buildStrategyCard(
          title: 'استراتيجية الضرب في 10',
          description: 'إضافة صفر في نهاية العدد.',
          example: '5 × 10 = 50',
          icon: Icons.exposure_plus_1,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية الضرب في 5',
          description: 'الضرب في 10 ثم القسمة على 2.',
          example: '8 × 5 = 8 × 10 ÷ 2 = 80 ÷ 2 = 40',
          icon: Icons.exposure,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية الضرب في 9',
          description: 'الضرب في 10 ثم طرح العدد الأصلي.',
          example: '7 × 9 = 7 × 10 - 7 = 70 - 7 = 63',
          icon: Icons.exposure_neg_1,
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: أجب عن أسئلة الضرب التالية',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildQuizCard(
          questions: [
            {
              'question': '7 × 9 = ?',
              'options': [61, 62, 63, 64],
              'correctAnswer': 63,
            },
            {
              'question': '8 × 5 = ?',
              'options': [35, 40, 45, 50],
              'correctAnswer': 40,
            },
            {
              'question': '6 × 10 = ?',
              'options': [50, 60, 70, 80],
              'correctAnswer': 60,
            },
            {
              'question': '9 × 9 = ?',
              'options': [71, 81, 91, 99],
              'correctAnswer': 81,
            },
            {
              'question': '4 × 7 = ?',
              'options': [24, 28, 32, 36],
              'correctAnswer': 28,
            },
          ],
        ),
      ],
    );
  }

  Widget _buildFourthLessonContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'القسمة السريعة',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'في هذا الدرس سنتعلم طرق القسمة السريعة ذهنياً. هناك عدة استراتيجيات يمكن استخدامها لإجراء عمليات القسمة بسرعة ودقة دون الحاجة إلى الورقة والقلم.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        _buildStrategyCard(
          title: 'استراتيجية القسمة على 10',
          description: 'حذف الصفر من نهاية العدد.',
          example: '50 ÷ 10 = 5',
          icon: Icons.exposure_minus_1,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية القسمة على 5',
          description: 'الضرب في 2 ثم القسمة على 10.',
          example: '45 ÷ 5 = 45 × 2 ÷ 10 = 90 ÷ 10 = 9',
          icon: Icons.exposure_minus_2,
        ),
        const SizedBox(height: 16),
        _buildStrategyCard(
          title: 'استراتيجية القسمة على 2',
          description: 'تنصيف العدد.',
          example: '46 ÷ 2 = 23',
          icon: Icons.call_split,
        ),
        const SizedBox(height: 24),
        const Text(
          'تمرين: أجب عن أسئلة القسمة التالية',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildQuizCard(
          questions: [
            {
              'question': '45 ÷ 5 = ?',
              'options': [7, 8, 9, 10],
              'correctAnswer': 9,
            },
            {
              'question': '60 ÷ 10 = ?',
              'options': [4, 5, 6, 7],
              'correctAnswer': 6,
            },
            {
              'question': '36 ÷ 4 = ?',
              'options': [7, 8, 9, 10],
              'correctAnswer': 9,
            },
            {
              'question': '81 ÷ 9 = ?',
              'options': [7, 8, 9, 10],
              'correctAnswer': 9,
            },
            {
              'question': '72 ÷ 8 = ?',
              'options': [7, 8, 9, 10],
              'correctAnswer': 9,
            },
          ],
        ),
      ],
    );
  }

  Widget _buildStrategyCard({
    required String title,
    required String description,
    required String example,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  icon,
                  color: Colors.blue.shade700,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            description,
            style: const TextStyle(
              fontSize: 14,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.lightbulb,
                  color: Colors.amber,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'مثال: $example',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuizCard({
    required List<Map<String, dynamic>> questions,
  }) {
    if (_quizCompleted) {
      return _buildQuizResults();
    }

    final currentQuestion = questions[_currentQuestionIndex];
    final questionText = currentQuestion['question'] as String;
    final options = currentQuestion['options'] as List<int>;
    final correctAnswer = currentQuestion['correctAnswer'] as int;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        children: [
          Text(
            'السؤال ${_currentQuestionIndex + 1} من ${questions.length}',
            style: TextStyle(
              fontSize: 14,
              color: Colors.blue.shade700,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                questionText,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 2,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: options.length,
            itemBuilder: (context, index) {
              final option = options[index];
              final isSelected = _selectedAnswer == option;
              
              return ElevatedButton(
                onPressed: _selectedAnswer != null ? null : () {
                  setState(() {
                    _selectedAnswer = option;
                    
                    if (option == correctAnswer) {
                      // إجابة صحيحة
                      _score++;
                      _showFeedback(context, true, 'إجابة صحيحة! 👍');
                    } else {
                      // إجابة خاطئة
                      _showFeedback(context, false, 'إجابة خاطئة. الإجابة الصحيحة هي: $correctAnswer');
                    }
                    
                    // انتظر قليلاً قبل الانتقال للسؤال التالي
                    Future.delayed(const Duration(seconds: 2), () {
                      setState(() {
                        if (_currentQuestionIndex < questions.length - 1) {
                          _currentQuestionIndex++;
                          _selectedAnswer = null;
                        } else {
                          _quizCompleted = true;
                        }
                      });
                    });
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _selectedAnswer == null 
                      ? Colors.white 
                      : isSelected 
                          ? option == correctAnswer 
                              ? Colors.green.shade100 
                              : Colors.red.shade100
                          : option == correctAnswer && _selectedAnswer != null
                              ? Colors.green.shade100
                              : Colors.white,
                  foregroundColor: _selectedAnswer == null 
                      ? Colors.blue.shade700 
                      : isSelected 
                          ? option == correctAnswer 
                              ? Colors.green.shade700 
                              : Colors.red.shade700
                          : Colors.blue.shade700,
                  padding: const EdgeInsets.all(16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: _selectedAnswer == null 
                          ? Colors.blue.shade200 
                          : isSelected 
                              ? option == correctAnswer 
                                  ? Colors.green 
                                  : Colors.red
                              : option == correctAnswer && _selectedAnswer != null
                                  ? Colors.green
                                  : Colors.blue.shade200,
                    ),
                  ),
                ),
                child: Text(
                  option.toString(),
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: (_currentQuestionIndex + 1) / questions.length,
            backgroundColor: Colors.grey.shade200,
            color: Colors.blue,
            minHeight: 8,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
    );
  }

  Widget _buildQuizResults() {
    final percentage = (_score / 5) * 100;
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        children: [
          const Text(
            'نتيجة الاختبار',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: percentage >= 80 
                  ? Colors.green.shade50 
                  : percentage >= 60 
                      ? Colors.amber.shade50 
                      : Colors.red.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Icon(
                  percentage >= 80 
                      ? Icons.emoji_events 
                      : percentage >= 60 
                          ? Icons.thumb_up 
                          : Icons.thumb_down,
                  color: percentage >= 80 
                      ? Colors.amber 
                      : percentage >= 60 
                          ? Colors.amber.shade700 
                          : Colors.red,
                  size: 48,
                ),
                const SizedBox(height: 16),
                Text(
                  '$_score / 5',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: percentage >= 80 
                        ? Colors.green.shade700 
                        : percentage >= 60 
                            ? Colors.amber.shade700 
                            : Colors.red.shade700,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${percentage.toInt()}%',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: percentage >= 80 
                        ? Colors.green.shade700 
                        : percentage >= 60 
                            ? Colors.amber.shade700 
                            : Colors.red.shade700,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  percentage >= 80 
                      ? 'ممتاز! أحسنت العمل.' 
                      : percentage >= 60 
                          ? 'جيد! استمر في التدريب.' 
                          : 'تحتاج إلى مزيد من التدريب.',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                _currentQuestionIndex = 0;
                _selectedAnswer = null;
                _score = 0;
                _quizCompleted = false;
              });
            },
            icon: const Icon(Icons.refresh),
            label: const Text('إعادة الاختبار'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue.shade50,
              foregroundColor: Colors.blue.shade700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLessonNavigation() {
    final hasNextLesson = _selectedLessonIndex < _units[_selectedUnitIndex]['lessons'].length - 1;
    final hasNextUnit = _selectedUnitIndex < _units.length - 1;
    final hasPreviousLesson = _selectedLessonIndex > 0;
    final hasPreviousUnit = _selectedUnitIndex > 0;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        if (hasPreviousLesson || hasPreviousUnit)
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                if (hasPreviousLesson) {
                  _selectedLessonIndex--;
                } else if (hasPreviousUnit) {
                  _selectedUnitIndex--;
                  _selectedLessonIndex = _units[_selectedUnitIndex]['lessons'].length - 1;
                }
                
                // إعادة تعيين متغيرات التمارين عند تغيير الدرس
                _selectedAnswer = null;
                _selectedNumbers = [];
                _score = 0;
                _currentQuestionIndex = 0;
                _quizCompleted = false;
              });
            },
            icon: const Icon(Icons.arrow_back),
            label: const Text('الدرس السابق'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.grey.shade200,
              foregroundColor: Colors.black,
            ),
          )
        else
          const SizedBox(),
        ElevatedButton(
          onPressed: () {
            setState(() {
              _isLessonView = false;
            });
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue.shade700,
            foregroundColor: Colors.white,
          ),
          child: const Text('إنهاء الدرس'),
        ),
        if (hasNextLesson || hasNextUnit)
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                if (hasNextLesson) {
                  _selectedLessonIndex++;
                } else if (hasNextUnit) {
                  _selectedUnitIndex++;
                  _selectedLessonIndex = 0;
                }
                
                // إعادة تعيين متغيرات التمارين عند تغيير الدرس
                _selectedAnswer = null;
                _selectedNumbers = [];
                _score = 0;
                _currentQuestionIndex = 0;
                _quizCompleted = false;
              });
            },
            icon: const Icon(Icons.arrow_forward),
            label: const Text('الدرس التالي'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue.shade700,
              foregroundColor: Colors.white,
            ),
          )
        else
          const SizedBox(),
      ],
    );
  }

  Widget _buildCourseStats() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'إحصائيات التقدم',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem('الدروس المكتملة', '${_getCompletedLessonsCount()}/${_getTotalLessons()}', Icons.check_circle, Colors.blue),
              _buildStatItem('الوقت المستغرق', '55 دقيقة', Icons.access_time, Colors.orange),
              _buildStatItem('النقاط المكتسبة', '150', Icons.star, Colors.amber),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            icon,
            color: color,
            size: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // دالة لعرض التغذية الراجعة للطالب
  void _showFeedback(BuildContext context, bool isCorrect, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isCorrect ? Icons.check_circle : Icons.error,
              color: Colors.white,
            ),
            const SizedBox(width: 8),
            Text(message),
          ],
        ),
        backgroundColor: isCorrect ? Colors.green : Colors.red,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  int _getTotalUnits() {
    return _units.length;
  }

  int _getTotalLessons() {
    int count = 0;
    for (final unit in _units) {
      final lessons = unit['lessons'] as List<Map<String, dynamic>>;
      count += lessons.length;
    }
    return count;
  }

  int _getCompletedLessonsCount() {
    int count = 0;
    for (int i = 0; i < _units.length; i++) {
      final lessons = _units[i]['lessons'] as List<Map<String, dynamic>>;
      for (int j = 0; j < lessons.length; j++) {
        if (lessons[j]['completed'] == true) {
          count++;
        }
      }
    }
    return count;
  }

  int _getTotalDuration() {
    int minutes = 0;
    for (final unit in _units) {
      final lessons = unit['lessons'] as List<Map<String, dynamic>>;
      for (final lesson in lessons) {
        final duration = lesson['duration'] as String;
        final durationMinutes = int.parse(duration.split(' ')[0]);
        minutes += durationMinutes;
      }
    }
    return minutes;
  }
}
